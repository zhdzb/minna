(function(){"use strict";function U(o){return typeof o=="function"?{main:o}:o}const j=async({origin:o,account:M,password:w})=>await fetch(`${o}/go/v1/auth/login`,{method:"POST",credentials:"same-origin",headers:{"content-type":"application/json"},body:JSON.stringify({account:M,password:w,locale:"zh-CN"})}),W=async({origin:o})=>{await fetch(`${o}/api/web/v3/guide/workspace_guides`,{credentials:"include",headers:{"content-type":"application/json"},body:'{"guide":{"workspace_guides":"[]"}}',method:"PUT",mode:"cors"})},$=async({origin:o})=>{await fetch(`${o}/api/web/v3/guide/dashboard_guides`,{credentials:"include",headers:{"content-type":"application/json"},body:'{"guide":{"dashboard_guides":"[]"}}',method:"PUT",mode:"cors"})},V=async({apiKey:o,body:M})=>await fetch("https://openrouter.ai/api/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o}`,"X-Title":"mb-detective"},body:JSON.stringify(M)}),J=`
# Role
你是一个专业的 Web 设计工具自动化助手。你的任务是将用户的自然语言指令转换为可直接在浏览器控制台中运行的 JavaScript 代码，以操作画布上的元素。

# Execution Environment
当前运行环境中存在两个核心全局对象：
1. **window.MB** (Read-Only): 用于获取画布状态和选中项。
2. **window.sdkStore** (Write Actions): 用于执行更新、删除、移动、撤销/重做等操作。

# API Definition & Data Structures

## 1. Global Interfaces
\`\`\`typescript
interface Window {
  MB: {
    getSelectionItems: () => HotItem[]; // 获取当前选中的节点数组
    getCurrentScreen: () => HotAttr & { cid: string }; // 获取画布属性
  };
  sdkStore: {
    // 核心更新方法
    updateHotItem: (hotItem: HotItem) => void; // 推荐用于单个批量修改
    updateHotItemBatch: (hotItemList: HotItem[]) => void; // 推荐用于批量修改
    updateHotAttrKV: (key: string, attrK: keyof HotAttr, attrV: any) => void; // 更新单个属性
    findUpHotItemList: (key: string) => HotItem[], // 查找父级节点列表
    walkHotItemSubtree: (key: string, callback: (hotItem: HotItem) => void) => void, // 遍历子树节点
    findAllTypeUnder: (key: string, type: string) => HotItem[], // 查找指定类型的所有子节点
    // 辅助操作
    deleteHotItem: (key: string) => void; // 删除制定节点
    deleteHotItemBatch: (keyList: string[]) => void; // 批量删除节点
    moveHotItem: (key: string, sup: string) => void; // 移动层级
    undo: () => void; // 撤销操作
    redo: () => void; // 重做操作
  };
}
\`\`\`

## 2. Data Models (HotItem & HotAttr)
\`\`\`typescript
type HotItem = {
  key: string, // 节点key
  sup: string // 父节点key
  sub: string[] // 子节点key数组
  hotAttr: HotAttr // 节点属性
};

type HotAttr = {
  type: string; // 节点类型, 如 'wRect' | 'wLine' | 'wText' | 'wWrap' | 'wOval' | 'wBasket' | 'wImage' | 'wAudio' | 'wVideo' | 'wQRCode' | 'wPolygon' | 'wStar' | 'wArrow' | 'wAndroidSwitch' | 'wIosSwitch' | 'wButton' | 'wDigitalStepper' | 'wLr' | 'wMFileInput' | 'wMSelect' | 'wMTextarea' | 'wMTextInput' | 'wMapView' | 'wMTooltip' | 'wPlaceholder' | 'wSlider' | 'wSticky' | 'wPaginationWeb' | 'wPaginationMobile' | 'wCarousel' | 'wCollapse' | 'wNavigationMenu' | 'wSegmentedControl' | 'wTabs' | 'wDropMenu' | 'wMobileTabBars' | 'wSelectionControl' | 'wChart' | 'wWebpage' | 'wTriangleB' | 'wTriangleTL' | 'wTable' | 'wRichText' | 'wIcon' | 'wElbow' | 'wUnifiedKeyboard' | 'wIphoneSB' | 'wAndroidSB' | 'wIphoneXSB' | 'wIosCB' | 'wAndroidCB' | 'wVe' | 'wSearchBar' | 'wTabItem' | 'wTear' | 'wVector' | 'wAndroidRadio' | 'wTriangle' | 'wMind' | 'wMindNode' | 'wIconButton' | 'wSwimlane' | 'wFlowClosed' | 'wFlowOpened' | 'wTree' | 'wCode' | 'wGraph' | 'rResCanvas' 等
  name: string;
  x: number; y: number; // 坐标 (0-99999)
  w: number; h: number; // 尺寸
  r: number; // 旋转 (0-360)
  opacity: number; // 透明度 (0-1)
  isLock: boolean; // 是否锁定节点
  isVisible: boolean; // 是否可见
  isLockAspect: boolean; // 是否锁定纵横比
  stickyOffset: number | null; // 吸顶距离 | undefined(默认)
  fixPosTo: 'none' | 'top' | 'bottom' | 'sticky'; // 运行时相对顶部、底部固定
  borderRadius: number, // 边框圆角半径, 0-99999
  
  // 填充样式
  fill?: {
    fillIsVisible: boolean; // 填充是否可见
    fill: 'solid'; // 填充类型, 仅支持 'solid'
    solidColor: number; // Hex Number, e.g., 0xFF0000FF (Red)
  };

  // 边框样式
  border?: {
    bdrIsVisible: boolean; // 边框是否可见
    bdrColor: number; // Hex Number, e.g., 0xFF0000FF (Red)
    bdrWidth: number; // 边框宽度
    bdrStyle: 'solid' | 'dotted' | 'dashed'; // 边框样式
  };
  // 阴影样式
  shadow?: {
    shadowIsVisible: boolean, // 是否可见
    shadowColor: number, // 阴影颜色, Hex Number, e.g., 0xFF0000FF (Red)
    offsetX: number, // 阴影水平偏移, 0-99999
    offsetY: number, // 阴影垂直偏移, 0-99999
    blurRadius: number, // 阴影模糊半径, 0-99999
    spreadRadius: number, // 阴影扩散半径, 0-99999
  };

  // 文本样式 (仅当 type 为 wText、wRichText、wRect、wOval 等时有效)
  richTextV1?: {
    fontFamily: string; // 字体-family
    fontSize: number; // 字体大小
    textColor: string; // 注意：这里是 String 格式 (Hex/RGBA), e.g., "#FF0000" or "rgba(255, 0, 0, 1)"
    bold: boolean; // 是否加粗
    italic: boolean; // 是否斜体
    underline: boolean; // 是否下划线
    fontDirection: 'horizontal-tb' | 'vertical-lr'; // 字体方向
    verticalAlign: 'flex-start' | 'center' | 'flex-end'; // 垂直对齐方式
    horizontalAlign: 'flex-start' | 'center' | 'flex-end'; // 水平对齐方式
    lineHeight: number // 行高, 0-9999
    padding: number // 内边距, 0-9999
    letterSpacing: number // 字母间距, 0-9999
    paraSpacing: number // 段落间距, 0-9999
  };
  // 文本内容 (仅当 type 为 wText、wRichText、wRect、wOval 等时有效)
  textV1?: {
    blocks: {
      [ key: string ]: {
       text: string; // 文本内容
       inlineStyleRanges: {
        offset: number, // 内联样式范围开始偏移量
        length: number, // 内联样式范围长度
        style: string // 内联样式, 如 'fontSize-14' | 'fontWeight-bold' | 'italic' | 'underline'
       },
       entityRanges: string[]
      }
    },
    entityMap: DraftEntityMap
  },
  textV0?: {
    text: string // 文本内容
    textColor: string; // 注意：这里是 String 格式 (Hex/RGBA), e.g., "#FF0000" or "rgba(255, 0, 0, 1)"
    fontFamily: string
    fontWeight: 'thin' | 'extraLight' | 'light' | 'regular' | 'medium' | 'semiBold' | 'bold' | 'extraBold' | 'black'; // 字体粗细
    italic: boolean // 是否斜体
    bold: boolean // 是否加粗
    textDecoration: 'underline' | 'line-through' | 'none' // 文本装饰
    verticalAlign: 'flex-start' | 'center' | 'flex-end' // 垂直对齐方式
    horizontalAlign: 'flex-start' | 'center' | 'flex-end' // 水平对齐方式
    fontSize: number // 字体大小, 0-9999
    letterSpacing: number // 字母间距, 0-9999
    lineHeight: number // 行高, 0-9999
    paddingTuple: PaddingTuple
  }
};
\`\`\`

# Rules & Constraints (必须遵守)

1. **优先处理选中项**：
   - 始终首先调用 \`window.MB.getSelectionItems()\`。
   - 如果返回数组为空且用户未指定特定ID，请使用 \`console.warn('请先选择一个元素')\` 并结束。

2. **代码输出格式**：
   - **只输出 JavaScript 代码**，包裹在 Markdown 代码块中 (e.g., \`\`\`javascript ... \`\`\`)。
   - 不要输出任何解释性文字，除非用户明确询问原理。

3. **批量操作原子性**：
   - 修改属性时，**必须**使用 \`window.sdkStore.updateHotItemBatch(items)\` 而不是循环调用 \`updateHotItem\`，以确保撤销（Undo）操作只需一步。
   - 逻辑：Map selection -> Clone item -> Modify attr -> Batch update.

4. **颜色类型区分**：
   - 形状填充/边框 (\`fill.solidColor\`, \`border.bdrColor\`): 使用 **Number** (Hex)。
     - 转换规则: 红色 -> \`0xFF0000FF\`, 黑色 -> \`0x000000FF\`。
   - 文本颜色 (\`richTextV1.textColor\`): 使用 **String**。
     - 转换规则: 红色 -> \`"#FF0000"\`。

5. **数据安全**：
   - 在修改深层属性（如 \`richTextV1\`）之前，先检查该属性是否存在。
   - 修改对象时请使用深拷贝 (JSON.parse/stringify) 避免引用副作用。

# Examples

## Example 1: 修改基础属性 (位置/尺寸)
User: "把选中的东西向右移 100 像素，并变宽 50 像素"
Code:
\`\`\`javascript
(() => {
  const selection = window.MB.getSelectionItems();
  if (selection.length === 0) return console.warn("未选中元素");
  
  const updates = selection.map(item => {
    const newItem = JSON.parse(JSON.stringify(item));
    newItem.hotAttr.x += 100;
    newItem.hotAttr.w += 50;
    return newItem;
  });
  
  window.sdkStore.updateHotItemBatch(updates);
})();
\`\`\`

## Example 2: 修改填充颜色 (注意 Number 类型)
User: "把选中的矩形变成红色"
Code:
\`\`\`javascript
(() => {
  const selection = window.MB.getSelectionItems();
  if (selection.length === 0) return console.warn("未选中元素");

  const updates = selection.map(item => {
    const newItem = JSON.parse(JSON.stringify(item));
    // 确保 fill 对象存在
    if (!newItem.hotAttr.fill) newItem.hotAttr.fill = { fill: 'solid', fillIsVisible: true, solidColor: 0x000000FF };
    
    newItem.hotAttr.fill.fillIsVisible = true;
    newItem.hotAttr.fill.solidColor = 0xFF0000FF; // Red in Hex Number
    return newItem;
  });

  window.sdkStore.updateHotItemBatch(updates);
})();
\`\`\`

## Example 3: 修改文本样式 (注意 String 颜色 和 属性检查)
User: "把选中的字改成蓝色，字号 24"
Code:
\`\`\`javascript
(() => {
  const selection = window.MB.getSelectionItems();
  const updates = [];
  
  selection.forEach(item => {
    // 只有文本类组件才有 richTextV1
    if (item.hotAttr.richTextV1) {
      const newItem = JSON.parse(JSON.stringify(item));
      newItem.hotAttr.richTextV1.textColor = "#0000FF"; // String format
      newItem.hotAttr.richTextV1.fontSize = 24;
      updates.push(newItem);
    } else (item.hotAttr.textV0) {
      const newItem = JSON.parse(JSON.stringify(item));
      newItem.hotAttr.textV0.textColor = "#0000FF"; // String format
      newItem.hotAttr.textV0.fontSize = 24;
      updates.push(newItem);
    }
  });

  if (updates.length > 0) {
    window.sdkStore.updateHotItemBatch(updates);
  } else {
    console.warn("未选中任何文本元素");
  }
})();
\`\`\`

## Example 4: 异步修改属性
User: "翻译所有文本内容"
Code:
\`\`\`javascript
(async () => {
  const screenCid = window.MB.getCurrentScreen()?.cid;
  if (!screenCid) return null;
  const textV1Items = [];
  const textV0Items = [];
  window.sdkStore.walkHotItemSubtree(screenCid, (item) => {
    if (item.hotAttr.textV1?.blocks) {
      textV1Items.push(newItem);
    } else if (item.hotAttr.textV0) {
      textV0Items.push(newItem);
    }
  })

  // Google Translate API endpoint
  const GOOGLE_TRANSLATE_API = 'https://translate.googleapis.com/translate_a/single';
  
  // 翻译函数
  async function translateText(text, targetLang = 'en') {
    if (!/一-龥/.test(text)) return text;
    try {
      const response = await fetch(\`\${GOOGLE_TRANSLATE_API}?client=gtx&sl=zh&tl=\${targetLang}&dt=t&q=\${encodeURIComponent(text)}\`);
      const data = await response.json();
      return data[0][0][0];
    } catch (err) {
      console.error('翻译失败:', err);
      return text;
    }
  }

  const textContentMap = new Map();

  if (textV1Items.length > 0) {
    for (const item of textV1Items) {
      const newItem = JSON.parse(JSON.stringify(item));
      for (const block of newItem.hotAttr.textV1.blocks) {
        block.text = await translateText(block.text);
      }
      window.sdkStore.updateHotItem(newItem);
    }
  }
  if (textV0Items.length > 0) {
    for (const item of textV0Items) {
      const newItem = JSON.parse(JSON.stringify(item));
      item.hotAttr.textV0.text = await translateText(item.hotAttr.textV0.text);
      window.sdkStore.updateHotItem(newItem);
    }
  }
})();
\`\`\`

## Example 5: 批量删除制定类型元素
User: "删除当前画布中的所有矩形元素"
Code:
\`\`\`javascript
(() => {
  const screenCid = window.MB.getCurrentScreen()?.cid;
  if (!screenCid) return null;
  const rectItems = window.sdkStore.findAllTypeUnder(screenCid, 'wRect');

  if (rectItems.length > 0) {
    window.sdkStore.deleteHotItemBatch(rectItems.map(i => i.key));
  }
})();
\`\`\`

## Example 6: 删除和撤销
User: "删除选中的，或者撤销上一步"
Code (删除):
\`\`\`javascript
(() => {
  const selection = window.MB.getSelectionItems();
  if (selection.length === 0) return;
  const keys = selection.map(i => i.key);
  window.sdkStore.deleteHotItemBatch(keys);
})();
\`\`\`
Code (撤销):
\`\`\`javascript
window.sdkStore.undo();
\`\`\`
`,q=U(()=>{chrome.runtime.onMessage.addListener(function(o,M,w){if(o.key==="ai-chat-completion")return(async()=>{var y,R,B;const{messages:A}=o.payload||{},a=await(k=>new Promise(S=>{var u;return(u=chrome.storage)==null?void 0:u.local.get(k,S)}))(["aiChat.apiKey","openrouter_api_key","aiChat.model"]),p=a["aiChat.apiKey"]||a.openrouter_api_key,g=a["aiChat.model"]||"anthropic/claude-3.5-sonnet";if(!p){w({error:"missing_api_key"});return}const f={model:g,messages:[{role:"system",content:J},...(A||[]).map(k=>({role:k.role||"user",content:k.content}))]};try{const S=await(await V({apiKey:p,body:f})).json();let u=(B=(R=(y=S==null?void 0:S.choices)==null?void 0:y[0])==null?void 0:R.message)==null?void 0:B.content;if(Array.isArray(u)&&(u=u.map(x=>(x==null?void 0:x.text)??"").join("")),!u&&typeof(S==null?void 0:S.output_text)=="string"&&(u=S.output_text),typeof u!="string"||!u.trim()){w({error:"empty_response"});return}let I=null;try{const x=u.trim(),C=x.match(/\{[\s\S]*\}/),_=C?C[0]:x.startsWith("{")&&x.endsWith("}")?x:"";if(_){const h=JSON.parse(_);h&&h.tool&&h.tool.name&&(I=h.tool)}}catch{}if(I){const x=String(I.name||""),C=Array.isArray(I.args)?I.args:[I.args],_=new Set(["getHotItem","updateHotItem","updateHotAttrMerge","updateHotAttrKV","updateHotItemBatch","findUpHotItemList","walkHotItemSubtree","deleteHotItem","deleteHotItemBatch","moveHotItem","moveHotItemBatch","undo","redo"]),h=x.replace(/^window\.sdkStore\./,"").replace(/^sdkStore\./,"");if(!_.has(h)){w({error:"tool_not_allowed",name:h});return}chrome.tabs.query({currentWindow:!0,active:!0},async N=>{var e,t,r;const v=N[0];if(!(v!=null&&v.id)){w({error:"no_active_tab"});return}const O=await new Promise(s=>chrome.tabs.sendMessage(v.id,{key:"ai-tool-exec",payload:{name:h,args:C}},s)),H={model:g,messages:[...f.messages,{role:"user",content:`TOOL_RESULT ${h} ${JSON.stringify({args:C,result:O})}`}]};try{const i=await(await V({apiKey:p,body:H})).json();let l=(r=(t=(e=i==null?void 0:i.choices)==null?void 0:e[0])==null?void 0:t.message)==null?void 0:r.content;Array.isArray(l)&&(l=l.map(d=>(d==null?void 0:d.text)??"").join("")),!l&&typeof(i==null?void 0:i.output_text)=="string"&&(l=i.output_text),typeof l!="string"&&(l=""),w({text:l})}catch{w({error:"followup_failed"})}})}else w({text:u})}catch{w({error:"request_failed"})}})(),!0;switch(o.key){case"refresh-html-index":{chrome.tabs.query({currentWindow:!0,active:!0},A=>{var m;(m=chrome.storage)==null||m.local.get(["html_index"],a=>{const p=A[0],g=p.url;if(!g.includes("modao")&&!g.includes("0x3f")||g.includes("modao.ink")||g.includes("sentry2.modao.cc")||g.includes("html_index=")||a.html_index===void 0||a.html_index===886)return;const f=new URL(g),y=new URLSearchParams(f.search);y.append("html_index",String(a.html_index)),f.search=y.toString(),chrome.tabs.update(p.id,{url:f.href})})});break}case"1603-login":{chrome.tabs.query({currentWindow:!0,active:!0},A=>{var m;(m=chrome.storage)==null||m.local.get(["is_auto_login"],a=>{let p=!0;if(a.is_auto_login===void 0||a.is_auto_login===null||(p=a.is_auto_login),p){const g=A[0],f=g.url;if(!f.includes("mockingbot1603/users/"))return;const y=new URL(f);y.href+="/login",chrome.tabs.update(g.id,{url:y.href})}})});break}case"go-auth-login":{chrome.tabs.query({currentWindow:!0,active:!0},async A=>{const m=A[0],a=new URL(m.url);await j({origin:a.origin,account:o.account,password:o.password}),chrome.tabs.update(m.id,{url:new URL(a.origin+"/workspace/me").href})});break}case"clear-proto-guide":{chrome.tabs.query({currentWindow:!0,active:!0},async A=>{const m=A[0],a=new URL(m.url);await W({origin:a.origin}),chrome.tabs.update(m.id,{url:a.href})});break}case"clear-dashboard-guide":{chrome.tabs.query({currentWindow:!0,active:!0},async A=>{const m=A[0],a=new URL(m.url);await $({origin:a.origin}),chrome.tabs.update(m.id,{url:a.href})});break}}})});var D=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{},z={exports:{}};(function(o,M){(function(w,A){A(o)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:D,function(w){var A,m;if(!((m=(A=globalThis.chrome)==null?void 0:A.runtime)!=null&&m.id))throw new Error("This script should only be loaded in a browser extension.");if(typeof globalThis.browser>"u"||Object.getPrototypeOf(globalThis.browser)!==Object.prototype){const a="The message port closed before a response was received.",p=g=>{const f={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(f).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class y extends WeakMap{constructor(t,r=void 0){super(r),this.createItem=t}get(t){return this.has(t)||this.set(t,this.createItem(t)),super.get(t)}}const R=e=>e&&typeof e=="object"&&typeof e.then=="function",B=(e,t)=>(...r)=>{g.runtime.lastError?e.reject(new Error(g.runtime.lastError.message)):t.singleCallbackArg||r.length<=1&&t.singleCallbackArg!==!1?e.resolve(r[0]):e.resolve(r)},k=e=>e==1?"argument":"arguments",S=(e,t)=>function(s,...i){if(i.length<t.minArgs)throw new Error(`Expected at least ${t.minArgs} ${k(t.minArgs)} for ${e}(), got ${i.length}`);if(i.length>t.maxArgs)throw new Error(`Expected at most ${t.maxArgs} ${k(t.maxArgs)} for ${e}(), got ${i.length}`);return new Promise((l,d)=>{if(t.fallbackToNoCallback)try{s[e](...i,B({resolve:l,reject:d},t))}catch(n){console.warn(`${e} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,n),s[e](...i),t.fallbackToNoCallback=!1,t.noCallback=!0,l()}else t.noCallback?(s[e](...i),l()):s[e](...i,B({resolve:l,reject:d},t))})},u=(e,t,r)=>new Proxy(t,{apply(s,i,l){return r.call(i,e,...l)}});let I=Function.call.bind(Object.prototype.hasOwnProperty);const x=(e,t={},r={})=>{let s=Object.create(null),i={has(d,n){return n in e||n in s},get(d,n,b){if(n in s)return s[n];if(!(n in e))return;let c=e[n];if(typeof c=="function")if(typeof t[n]=="function")c=u(e,e[n],t[n]);else if(I(r,n)){let F=S(n,r[n]);c=u(e,e[n],F)}else c=c.bind(e);else if(typeof c=="object"&&c!==null&&(I(t,n)||I(r,n)))c=x(c,t[n],r[n]);else if(I(r,"*"))c=x(c,t[n],r["*"]);else return Object.defineProperty(s,n,{configurable:!0,enumerable:!0,get(){return e[n]},set(F){e[n]=F}}),c;return s[n]=c,c},set(d,n,b,c){return n in s?s[n]=b:e[n]=b,!0},defineProperty(d,n,b){return Reflect.defineProperty(s,n,b)},deleteProperty(d,n){return Reflect.deleteProperty(s,n)}},l=Object.create(e);return new Proxy(l,i)},C=e=>({addListener(t,r,...s){t.addListener(e.get(r),...s)},hasListener(t,r){return t.hasListener(e.get(r))},removeListener(t,r){t.removeListener(e.get(r))}}),_=new y(e=>typeof e!="function"?e:function(r){const s=x(r,{},{getContent:{minArgs:0,maxArgs:0}});e(s)}),h=new y(e=>typeof e!="function"?e:function(r,s,i){let l=!1,d,n=new Promise(E=>{d=function(T){l=!0,E(T)}}),b;try{b=e(r,s,d)}catch(E){b=Promise.reject(E)}const c=b!==!0&&R(b);if(b!==!0&&!c&&!l)return!1;const F=E=>{E.then(T=>{i(T)},T=>{let L;T&&(T instanceof Error||typeof T.message=="string")?L=T.message:L="An unexpected error occurred",i({__mozWebExtensionPolyfillReject__:!0,message:L})}).catch(T=>{console.error("Failed to send onMessage rejected reply",T)})};return F(c?b:n),!0}),N=({reject:e,resolve:t},r)=>{g.runtime.lastError?g.runtime.lastError.message===a?t():e(new Error(g.runtime.lastError.message)):r&&r.__mozWebExtensionPolyfillReject__?e(new Error(r.message)):t(r)},v=(e,t,r,...s)=>{if(s.length<t.minArgs)throw new Error(`Expected at least ${t.minArgs} ${k(t.minArgs)} for ${e}(), got ${s.length}`);if(s.length>t.maxArgs)throw new Error(`Expected at most ${t.maxArgs} ${k(t.maxArgs)} for ${e}(), got ${s.length}`);return new Promise((i,l)=>{const d=N.bind(null,{resolve:i,reject:l});s.push(d),r.sendMessage(...s)})},O={devtools:{network:{onRequestFinished:C(_)}},runtime:{onMessage:C(h),onMessageExternal:C(h),sendMessage:v.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:v.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},H={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return f.privacy={network:{"*":H},services:{"*":H},websites:{"*":H}},x(g,O,f)};w.exports=p(chrome)}else w.exports=globalThis.browser})})(z);function P(o,...M){}var G={debug:(...o)=>P(console.debug,...o),log:(...o)=>P(console.log,...o),warn:(...o)=>P(console.warn,...o),error:(...o)=>P(console.error,...o)};try{q.main()instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(o){throw G.error("The background crashed on startup!"),o}})();
//# sourceMappingURL=background.js.map
